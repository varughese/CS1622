#include "factory.h"

// this should be able to take in the ast and print it out
// void print_expr(struct expr *expr);

char *stringify_abstract_syntax_tree(struct decl *root);