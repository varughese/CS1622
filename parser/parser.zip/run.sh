./parser $1 $2
# ./parser main.c main.ast && cat main.ast # Debug