void main(void)
{
    int a[10];
    while(g < 10)
    {
        g = foo(g, 2, a);
        ;
    }
}